
import GameEnvironment.Game;


/**
 * Ass3Game class.
 */
public class Ass3Game {


    /**
     * Main Method initialize gam and run animation.
     *
     * @param args no arguments for this method.
     */
    public static void main(String[] args) {


        Game game = new Game();
        game.initialize();
        game.run();


    }
}
