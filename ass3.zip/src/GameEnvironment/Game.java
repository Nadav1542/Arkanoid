package GameEnvironment;

import biuoop.DrawSurface;
import biuoop.GUI;

import java.awt.Color;
import Geometry.Ball;
import Geometry.Block;
import Geometry.Paddle;
import Geometry.Rectangle;
import Geometry.Point;
import Geometry.Collidable;
import biuoop.KeyboardSensor;

/**
 * Game class.
 */
public class Game {

    /**
     * The constant WINDOW_WIDTH.
     */
    public static final int WINDOW_WIDTH = 800;
    /**
     * The constant WINDOW_HEIGHT.
     */
    public static final int WINDOW_HEIGHT = 600;
    /**
     * The constant BLOCK_WIDTH.
     */

    /**
     * Sprites collection in the game.
     */
    private SpriteCollection sprites;
    /**
     * Game environment field which includes collidable list.
     */
    private GameEnvironment environment;
    /**
     * Paddle controlled by the user.
     */
    private Paddle userPaddle;
    /**
     * Gui which creates window for the game.
     */
    private GUI gui;

    /**
     * Method sets gui for the game.
     *
     * @param gui the gui
     */

    public void setGui(GUI gui) {
        this.gui = gui;
    }

    /**
     * Method return game environment field of game object.
     *
     * @return (GameEnvironment) game environment field of game object.
     */
    public GameEnvironment getEnvironment() {
        return this.environment;
    }


    /**
     * Method adding collidable to collidable list of objects in the game.
     *
     * @param c the c
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /**
     * Method adding sprite to sprite-collection in the game.
     *
     * @param s sprite to be added.
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }


    /**
     * Method initialize the game setting. Creating paddle,borders,blocks and
     * balls.
     */
    public void initialize() {
        GUI gui = new GUI("Arkanoid", 800, 600);
        this.setGui(gui);
        KeyboardSensor keyboardSensor = gui.getKeyboardSensor();
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        this.userPaddle = new Paddle(keyboardSensor, new Block(new Point(5,
                570), 125, 15, Color.magenta));
        this.userPaddle.addToGame(this);
        createBorders();
        Color[] c  = {Color.yellow, Color.pink, Color.blue, Color.green,
                Color.red, Color.gray};
        //creating pattern of blocks.
        for (int i = 0; i < 6; i++) {
            int y = 100 + 25 * i;
            for (int j = i + 1; j < 12; j++) {
                int x = 185 + 50 * j;
                Block block = new Block(new Point(x, y), 50,
                        25, c[i]);
                block.addtoGame(this);
            }
        }
        Ball gameBall = new Ball(new Point(300, 580), 5, Color.BLACK);
        Ball gameBall1 = new Ball(new Point(350, 530), 5, Color.BLACK);
        gameBall.addtoGame(this);
        gameBall1.addtoGame(this);
    }

    /**
     * Method create borders for the game.
     */
    public void createBorders() {
        Block rightborder =
                new Block(new Rectangle(
                        new Point(WINDOW_WIDTH - 15, 15), 15,
                        WINDOW_HEIGHT - 15), Color.darkGray);
        Block leftborder = new Block(new Rectangle(new Point(0, 15),
                15, WINDOW_HEIGHT - 15), Color.darkGray);
        Block upperborder = new Block(new Rectangle(new Point(0, 0),
                WINDOW_WIDTH, 15), Color.darkGray);
        Block bottomborder = new Block(new Rectangle(new Point(15,
                WINDOW_HEIGHT - 15),
                WINDOW_WIDTH - 15, 15), Color.darkGray);
        rightborder.addtoGame(this);
        leftborder.addtoGame(this);
        upperborder.addtoGame(this);
        bottomborder.addtoGame(this);
    }


    /**
     * Method runs animation on screen.
     */
    public void run() {
        biuoop.Sleeper sleeper = new biuoop.Sleeper();
        int framesPerSecond = 60;
        int millisecondsPerFrame = 1000 / framesPerSecond;
        while (true) {
            long startTime = System.currentTimeMillis(); // timing

            DrawSurface d = gui.getDrawSurface();
            this.sprites.drawAllOn(d);
            gui.show(d);
            this.sprites.notifyAllTimePassed();

            // timing
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }
}