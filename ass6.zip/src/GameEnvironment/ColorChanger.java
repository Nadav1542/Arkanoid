package GameEnvironment;

import Geometry.Ball;
import Geometry.Block;

public class ColorChanger implements HitListener{
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {

    }
}
