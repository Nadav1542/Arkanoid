/**
 *
 *
 * @author Nadav Mor 206492233 <\>.
 * @version JDK 19.
 * @since 2022-09-20.
 */

import biuoop.GUI;
import biuoop.DrawSurface;
import java.util.Random;
import java.awt.Color;

/**
 * AbstractArtDrawing class. this class draws 10 random lines.
 */
public class AbstractArtDrawing {

    /**
     * Method draw 10 random lines and fill middle points in blue dots and
     * intersection points in red dots.
     */
    public void drawRandomCircles() {
        Random rand = new Random(); // create a random-number generator
        // Create a window with the title "Random Circles Example"
        // which is 400 pixels wide and 300 pixels high.
        GUI gui = new GUI("Random Circles Example", 400, 300);
        DrawSurface d = gui.getDrawSurface();
        Line[] larray = new Line[10];
        for (int i = 0; i < 10; ++i) {
            int x1 = rand.nextInt(400) + 1; // get integer in range 1-400
            int y1 = rand.nextInt(300) + 1; // get integer in range 1-300
            int x2 = rand.nextInt(400) + 1; // get integer in 5,10,15,20
            int y2 = rand.nextInt(300) + 1; // get integer in 5,10,15,20
            Line l = new Line(x1, y1, x2, y2);
            larray[i] = l;
            Point pm = new Point(l.middle().getX(), l.middle().getY());
            d.setColor(Color.BLACK);
            d.drawLine(x1, y1, x2, y2);
            d.setColor(Color.BLUE);
            d.fillCircle((int) pm.getX(), (int) pm.getY(), 3);
        }
        for (int i = 0; i < 9; i++) {
            for (int j = i + 1; j < 10; j++) {
                Point pi = larray[i].intersectionWith(larray[j]);
                if (pi != null) {
                    d.setColor(Color.RED);
                    d.fillCircle((int) pi.getX(), (int) pi.getY(), 3);
                }
            }
        }
        gui.show(d);
    }

    /**
     * Main Method: creates instance of object and run drawRandomCircles()
     * method.
     *
     * @param args no arguments for this method.
     */
    public static void main(String[] args) {
        AbstractArtDrawing example = new AbstractArtDrawing();
        example.drawRandomCircles();
    }
}
