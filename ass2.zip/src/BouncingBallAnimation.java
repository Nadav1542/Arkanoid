/**
 * @author Nadav Mor 206492233 <\>.
 * @version JDK 19.
 * @since 2022-09-20.
 */

import biuoop.DrawSurface;
import biuoop.GUI;

import java.awt.Color;

/**
 * Bouncing ball animation class is creating animation of a given bouncing
 * ball given by user.
 */
public class BouncingBallAnimation {
    /**
     * given radius.
     */
    static final int RADIUS = 30;
    /**
     * The Rightborder.
     */
    static final int  RIGHTBORDER = 200;
    /**
     * The Upperborder.
     */
    static final int  UPPERBORDER = 0;
    /**
     * The Leftborder.
     */
    static final int  LEFTBORDER = 0;
    /**
     * The Bottomborder.
     */
    static final int  BOTTOMBORDER = 200;


    /**
     * Method returns true if given ball doesn't cross frame's borders.
     *
     * @param x x coordinate of center of ball.
     * @param y y coordinate of center of ball.
     * @return (boolean) (@code true) if point in correct range (@code false) otherwise.
     */
    static boolean checkSetting(double x, double y) {

        return (x - RADIUS) >= LEFTBORDER && (x + RADIUS) <= RIGHTBORDER
                && (y - RADIUS) >= UPPERBORDER && (y + RADIUS) <= BOTTOMBORDER;
    }

    /**
     * Method gets center point of ball and it's speed and drawing it's next
     * position on surface to create animation.
     *
     * @param strNum input for checking.
     * @return (boolean) (@code true) if argument is number (@code false) otherwise.
     */
    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            double d = Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    /**
     * Method get center point of ball and it's speed and drawing it's next
     * position on surface to create animation.
     *
     *
     * @param start center point of ball.
     * @param dx change in position in x axes.
     * @param dy change in position in y axes.
     *
     */
    static private void drawAnimation(Point start, double dx, double dy) {
        GUI gui = new GUI("title", 200, 200);
        biuoop.Sleeper sleeper = new biuoop.Sleeper();
        Ball ball = new Ball(start.getX(), start.getY(), 30, Color.black);
        ball.setVelocity(dx, dy);
        while (true) {
            ball.moveOneStep();
            DrawSurface d = gui.getDrawSurface();
            ball.drawOn(d);
            gui.show(d);
            sleeper.sleepFor(50); // wait for 50 milliseconds.
        }
    }

    /**
     * default center of ball.
     */
    static final Point DEFAULTCENTER = new Point(30, 30);

    /**
     * default change in position of position in x axes.
     */
    static final int DEFAULTDX = 5;
    /**
     * default change in position of position in y axes.
     */
    static final int DEFAULTDY = 5;

    /**
     * The main method of class. Gets input from user, check validity and
     * calls method to perform animation.
     *
     * @param args the input arguments which includes center point of ball,
     *             speed in axis x and speed in axis y.
     */
    public static void main(String[] args) {
        if (args.length < 4) {
            System.out.println("for setting ball needed 4 inputs for setting,"
                    + " default ball has been drawing");
            drawAnimation(DEFAULTCENTER, DEFAULTDX, DEFAULTDY);
        }
        if (isNumeric(args[0]) && isNumeric(args[1]) && isNumeric(args[2]) && isNumeric(args[3])) {
            double x = Double.parseDouble(args[0]);
            double y = Double.parseDouble(args[1]);
            double dx = Double.parseDouble(args[2]);
            double dy = Double.parseDouble(args[3]);
            if (!checkSetting(x, y)) {
                System.out.println("Invalid center point (out of range)"
                        + " has led to setting default " + "center point"
                        + "(30,30)");
                drawAnimation(DEFAULTCENTER, dx, dy);
            }
            drawAnimation(new Point(x, y), dx, dy);
        } else {
            System.out.println("Invalid argument (not numerical input) has "
                    + "led to set it to default ball");
            drawAnimation(DEFAULTCENTER, DEFAULTDX, DEFAULTDY);
        }
    }
}