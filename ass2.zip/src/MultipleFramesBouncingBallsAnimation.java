/**
 *
 *
 * @author Nadav Mor 206492233 <\>.
 * @version JDK 19.
 * @since 2022-09-20.
*/
import biuoop.DrawSurface;
import biuoop.GUI;

import java.awt.Color;
import java.util.Random;

/**
 * MultipleFramesBouncingBallsAnimation class. this class creates animation
 * of bouncing balls in gray 450x450 frame and in yellow 150x150
 * frame.
 */
public class MultipleFramesBouncingBallsAnimation {
    /**
     * The minimum radius of ball for frame one.
     */
    private static final double MAXRADIUSONE = 225;
    /**
     * The maximum radius of ball for frame two.
     */
    private static final double MAXRADIUSTWO = 75;
    /**
     * above HEAVY radius, ball's speed set to default speed.
     */
    private static final double HEAVY = 50;

    /**
     * Method drawing given balls in gray 450x450 frame and in yellow 150x150
     * frame.
     *
     * @param balls array of balls for drawing.
     * @param gui   object for creating surface.
     */
    static void drawPlayground(Ball[] balls,
                                       GUI gui) {
        biuoop.Sleeper sleeper = new biuoop.Sleeper();
        while (true) {
            DrawSurface surface = gui.getDrawSurface();
            surface.setColor(Color.gray);
            surface.fillRectangle(50, 50, 450, 450);
            for (int i = 0; i < balls.length / 2; i++) {
                balls[i].moveOneStep(new Point(50, 50), new Point(500, 500));
            }
            for (int i = 0; i < balls.length / 2; i++) {
                balls[i].drawOn(surface);
            }
            surface.setColor(Color.yellow);
            surface.fillRectangle(450, 450, 150, 150);
            for (int i = balls.length / 2; i < balls.length; i++) {
                balls[i].moveOneStep(new Point(450, 450), new Point(600, 600));
            }
            for (int i = balls.length / 2; i < balls.length; i++) {
                balls[i].drawOn(surface);
            }
            gui.show(surface);
            sleeper.sleepFor(50);
        }
    }


    /**
     * Method returns array of balls with random center position in each
     * frame (gray or yellow).
     *
     * @param radius array of sizes for each ball.
     * @return (Ball[]) returns array of ball instances.
     */
    static Ball[] createPlayground(int[] radius) {
        Ball[] balls = new Ball[radius.length];
        Random rand = new Random();
        //creating balls for gray frame.
        for (int i = 0; i < radius.length / 2; i++) {
            //checking if radius is too big.
            if (radius[i] >= MAXRADIUSONE) {
                System.out.println("radius of ball " + (i + 1) + " is " + radius[i]
                        + ", which is to big for the frame. radius replaced "
                        + "to 50.");
                radius[i] = (int) HEAVY;
            }
            float red = rand.nextFloat();
            float green = rand.nextFloat();
            float blue = rand.nextFloat();
            double x1 =
                    rand.nextInt((500 - radius[i]) - (50 + radius[i])) + (50 + radius[i]);
            double y1 =
                    rand.nextInt((500 - radius[i]) - (50 + radius[i])) + (50 + radius[i]);
            Ball ball = new Ball(x1, y1, radius[i],
                    new Color(red, green, blue));
            if (radius[i] >= HEAVY) {
                ball.setVelocity(1, 1); //default speed for big balls.
                balls[i] = ball;
                continue;
            }
            ball.setVelocity(MAXRADIUSTWO / radius[i],
                    MAXRADIUSTWO / radius[i]);
            balls[i] = ball;
        }
        //creating balls for yellow frame.
        for (int i = radius.length / 2; i < radius.length; i++) {
            //checking if radius is too big.
            if (radius[i] >= MAXRADIUSTWO) {
                System.out.println("radius of ball " + (i + 1) + " is " + radius[i]
                        + ", which is to big for the frame. radius replaced "
                        + " to 50. ");
                radius[i] = (int) HEAVY;
            }
            float red = rand.nextFloat();
            float green = rand.nextFloat();
            float blue = rand.nextFloat();
            double x1 =
                    rand.nextInt((600 - radius[i]) - (450 + radius[i])) + (450 + radius[i]);
            double y1 =
                    rand.nextInt((600 - radius[i]) - (450 + radius[i])) + (450 + radius[i]);
            Ball ball = new Ball(x1, y1, radius[i],
                    new Color(red, green, blue));
            if (radius[i] >= HEAVY) {
                ball.setVelocity(1, 1); //default speed for big balls.
                balls[i] = ball;
                continue;
            }
            //The bigger the ball, the slower it's speed.
            ball.setVelocity(MAXRADIUSTWO / radius[i],
                    MAXRADIUSTWO / radius[i]);
            balls[i] = ball;
        }
        return balls;
    }

    /**
     * Method creates array of balls for drawing.
     *
     * @param strNum array of wanted size for each ball.
     * @return (@ code true) if input is integer type. (@code false) otherwise.
     */
    public static boolean isInteger(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            double d = Integer.parseInt(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    /**
     * The Defaultradius.
     */
    static final int DEFAULTRADIUS = 10;

    /**
     * Main method. creates surface and calls method to draw wanted animation
     * on it.
     *
     * @param args array of sizes of each ball for drawing.
     */
    public static void main(String[] args) {
        if (args.length == 0) {
            throw new RuntimeException("for setting frame need at least two "
                    + "integer inputs");
        }
        int inputlen = args.length;
        int[] radius = new int[inputlen];
        for (int i = 0; i < inputlen; i++) {
            //check if input is integer
            if (!isInteger(args[i])) {
                System.out.println("Invalid input for size number "
                        + (i + 1) + " has led to set it to default size which "
                        + "is 10");
                radius[i] = DEFAULTRADIUS;
                continue;
            }
            //check if input is positive integer.
            if (Integer.parseInt(args[i]) <= 0) {
                System.out.println("Invalid radius for size number "
                        + (i + 1) + " has led to set it to default size which "
                        + "is 10");
                radius[i] = DEFAULTRADIUS;
                continue;
            }
            radius[i] = Integer.parseInt(args[i]);
        }
        GUI gui = new GUI("title", 700, 700);
        drawPlayground(createPlayground(radius), gui);
    }
}
