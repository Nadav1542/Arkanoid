/**
 * @author Nadav Mor 206492233 <\>.
 * @version JDK 19.
 * @since 2022-09-20.
 */

import biuoop.DrawSurface;
import biuoop.GUI;

import java.awt.Color;
import java.util.Random;

/**
 * MultipleBouncingBallsAnimation class. Creating animation of bouncing balls
 * on screen.
 */
public class MultipleBouncingBallsAnimation {

    /**
     * ball above this radius will have default speed.
     */
    private static final double HEAVY = 50;


    /**
     * Method creates array of balls for drawing.
     *
     * @param balls array of wanted balls for drawing.
     * @param gui   object which creates surface for drawing on.
     */
    static void drawPlayground(Ball[] balls, GUI gui) {
        biuoop.Sleeper sleeper = new biuoop.Sleeper();
        while (true) {
            DrawSurface surface = gui.getDrawSurface();
            for (int i = 0; i < balls.length; i++) {
                balls[i].moveOneStep(new Point(0, 0),
                        new Point(surface.getWidth(),
                                surface.getHeight()));
            }
            for (int i = 0; i < balls.length; i++) {
                balls[i].drawOn(surface);
            }
            gui.show(surface);
            sleeper.sleepFor(50);
        }

    }


    /**
     * Method creates array of balls for drawing.
     *
     * @param radius  array of wanted size for each ball.
     * @param surface surface to draw circles on.
     * @param maxR maximum radius of ball for drawing.
     * @return returns array of balls.
     */
    static Ball[] createPlayground(int[] radius, DrawSurface surface, int maxR) {
        Ball[] balls = new Ball[radius.length];
        Random rand = new Random();
        for (int i = 0; i < radius.length; i++) {
            float red = rand.nextFloat();
            float green = rand.nextFloat();
            float blue = rand.nextFloat();
            double x1 =
                    rand.nextInt((surface.getWidth() - radius[i]) - radius[i]) + radius[i];
            double y1 =
                    rand.nextInt((surface.getHeight() - radius[i]) - radius[i]) + radius[i];
            Ball ball = new Ball(x1, y1, radius[i],
                    new Color(red, green, blue));
            if (ball.getSize() >= HEAVY) {
                ball.setVelocity(1, 1); //default speed for big balls.
                balls[i] = ball;
                continue;
            }
            ball.setVelocity(maxR / radius[i], maxR / radius[i]);
            balls[i] = ball;
        }
        return balls;
    }

    /**
     * Method creates array of balls for drawing.
     *
     * @param strNum array of wanted size for each ball.
     * @return (@ code true) if radius is integer type. (@code false) otherwise.
     */
    public static boolean isInteger(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            double d = Integer.parseInt(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    /**
     * Main method. gets radius from user and checks it's validity and call
     * method for creating animation.
     *
     * @param args radius arguments from user which is size for each ball.
     */
    public static void main(String[] args) {
        int inputlen = args.length;
        int[] radius = new int[inputlen];
        GUI gui = new GUI("title", 300, 300);
        DrawSurface d = gui.getDrawSurface();
        int maxR = d.getWidth() / 2; //defined maximum size of ball.
        for (int i = 0; i < inputlen; i++) {
            //check if input is integer type.
            if (!isInteger(args[i])) {
                System.out.println("Invalid radius for size number "
                        + (i + 1) + " has led to set it to default size which "
                        + "is 10");
                radius[i] = 10;
                continue;
            }
            //check if input is positive integer.
            if (Integer.parseInt(args[i]) <= 0) {
                System.out.println("Invalid radius for size number "
                        + (i + 1) + " has led to set it to default size which "
                        + "is 10");
                radius[i] = 10;
                continue;
            }
            //check if size is not too big for drawing on surface.
            if (Integer.parseInt(args[i]) > maxR) {
                System.out.println("radius of ball " + (i + 1) + " is too big"
                        + ", radius replaced to maximum radius, "
                        + (maxR - 1));
                radius[i] = maxR - 1;
                continue;
            }
            radius[i] = Integer.parseInt(args[i]);
        }
        drawPlayground(createPlayground(radius, d, maxR), gui);
    }
}